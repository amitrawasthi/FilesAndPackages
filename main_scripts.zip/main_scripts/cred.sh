#!/bin/bash
echo "Exporting Variables: "
export PATH=$PATH:/bin/terraform
export AWS_ACCESS_KEY_ID="AKIAUZ4MDWWCENL3OI43"
export AWS_SECRET_ACCESS_KEY="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"
export AWS_DEFAULT_REGION="us-east-1"
