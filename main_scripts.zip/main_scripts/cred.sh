#!/bin/bash
echo "Exporting Variables: "
export PATH=$PATH:/bin/terraform
export AWS_ACCESS_KEY_ID="AKIAUAR7BHQZRTH7G2OS"
export AWS_SECRET_ACCESS_KEY="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"
export AWS_DEFAULT_REGION="us-east-2"
